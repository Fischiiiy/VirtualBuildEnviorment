
File Tab Styler v0.2 - Addin for FBEdit
----------------------------------------
written by krcko (admin@krcko.net)

Install:
--------
Just copy FileTabStyle.dll to Addin directory under FBEdit dir and (re)start FBEdit.


Usage:
------
Addin is controled trought the menu called 'File tab style' wich is located in the View menu.