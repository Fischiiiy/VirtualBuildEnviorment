HOWTO FILE PLACED ON:
http://www.piotrbania.com/all/disit/